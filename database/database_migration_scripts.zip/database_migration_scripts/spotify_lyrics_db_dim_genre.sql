CREATE DATABASE  IF NOT EXISTS `spotify_lyrics_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `spotify_lyrics_db`;
-- MySQL dump 10.13  Distrib 8.0.40, for macos14 (x86_64)
--
-- Host: 127.0.0.1    Database: spotify_lyrics_db
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dim_genre`
--

DROP TABLE IF EXISTS `dim_genre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dim_genre` (
  `genre_id` bigint unsigned NOT NULL DEFAULT '0',
  `genre_name` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dim_genre`
--

LOCK TABLES `dim_genre` WRITE;
/*!40000 ALTER TABLE `dim_genre` DISABLE KEYS */;
INSERT INTO `dim_genre` VALUES (1,'acoustic'),(2,'afrobeat'),(3,'alt-rock'),(4,'alternative'),(5,'ambient'),(6,'anime'),(7,'black-metal'),(8,'bluegrass'),(9,'blues'),(10,'brazil'),(11,'breakbeat'),(12,'british'),(13,'cantopop'),(14,'chicago-house'),(15,'children'),(16,'chill'),(17,'classical'),(18,'club'),(19,'comedy'),(20,'country'),(21,'dance'),(22,'dancehall'),(23,'death-metal'),(24,'deep-house'),(25,'detroit-techno'),(26,'disco'),(27,'disney'),(28,'drum-and-bass'),(29,'dub'),(30,'dubstep'),(31,'edm'),(32,'electro'),(33,'electronic'),(34,'emo'),(35,'folk'),(36,'forro'),(37,'french'),(38,'funk'),(39,'garage'),(40,'german'),(41,'gospel'),(42,'goth'),(43,'grindcore'),(44,'groove'),(45,'grunge'),(46,'guitar'),(47,'happy'),(48,'hard-rock'),(49,'hardcore'),(50,'hardstyle'),(51,'heavy-metal'),(52,'hip-hop'),(53,'honky-tonk'),(54,'house'),(55,'idm'),(56,'indian'),(57,'indie'),(58,'indie-pop'),(59,'industrial'),(60,'iranian'),(61,'j-dance'),(62,'j-idol'),(63,'j-pop'),(64,'j-rock'),(65,'jazz'),(66,'k-pop'),(67,'kids'),(68,'latin'),(69,'latino'),(70,'malay'),(71,'mandopop'),(72,'metal'),(73,'metalcore'),(74,'minimal-techno'),(75,'mpb'),(76,'new-age'),(77,'opera'),(78,'pagode'),(79,'party'),(80,'piano'),(81,'pop'),(82,'pop-film'),(83,'power-pop'),(84,'progressive-house'),(85,'psych-rock'),(86,'punk'),(87,'punk-rock'),(88,'r-n-b'),(89,'reggae'),(90,'reggaeton'),(91,'rock'),(92,'rock-n-roll'),(93,'rockabilly'),(94,'romance'),(95,'sad'),(96,'salsa'),(97,'samba'),(98,'sertanejo'),(99,'show-tunes'),(100,'singer-songwriter'),(101,'ska'),(102,'sleep'),(103,'songwriter'),(104,'soul'),(105,'spanish'),(106,'study'),(107,'swedish'),(108,'synth-pop'),(109,'tango'),(110,'techno'),(111,'trance'),(112,'trip-hop'),(113,'turkish'),(114,'world-music');
/*!40000 ALTER TABLE `dim_genre` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-29 15:42:56
